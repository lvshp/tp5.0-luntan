<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:63:"D:\xampp\htdocs\tp5.0\public/../app/index\view\index\index.html";i:1540361999;}*/ ?>
<!DOCTYPE html>
<html>
    <meta charset="utf-8">
    <head>
    </head>
    <body>
        <h1>Hello ThinkPHP5.0</h1>
    </body>
</html>