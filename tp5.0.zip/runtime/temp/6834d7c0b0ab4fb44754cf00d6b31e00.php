<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:65:"D:\xampp\htdocs\tp5.0\public/../app/admin\view\index\article.html";i:1541592123;s:55:"D:\xampp\htdocs\tp5.0\app\admin\view\public\header.html";i:1541574583;s:55:"D:\xampp\htdocs\tp5.0\app\admin\view\public\footer.html";i:1540609386;}*/ ?>
<html>
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=11">
        <meta name="application-name" content="ZeroDream">
        <meta name="msapplication-TileColor" content="#F1F1F1">
        <meta name="description" content="欢迎访问 ZeroDream 零梦开源交流论坛，这里是一个自由和谐的开源交流社区，同时也是 Sakura Frp 官方交流论坛，我们欢迎所有热爱原创、开源的人加入我们，一起愉快地交流一切有些意思的东西，无论是科技还是游戏。零梦开源交流论坛">
        <meta name="google-site-verification" content="uHNLZ4EM4Cfxsw4PCW3_ESvZXJUAxqRzh4chJDEHJPc">
        <meta name="baidu-site-verification" content="PruVNLBpoj">
        <meta name="keywords" content="TCOTP,NiconicoCraft,Minecraft,Server,服务端,我的世界,服务器,CraftBukkit,CB,Spigot,PaperSpigot,TorchSpigot,Thermos,BungeeCord,SpongeForge,SpongeVanilla,Sponge,WaterFall,GlowStone,Minecraft_Server">
        <title><?php echo $article['title']; ?></title>
        <link href="/css/bootstrap.css" rel="stylesheet">
        <link href="/css/font-awesome.css" rel="stylesheet">
        <link href="/css/animate.css" rel="stylesheet">
        <link href="/css/style.css" rel="stylesheet">
        <script src="/js/hm.js"></script><script src="/js/jquery.js"></script>
        <script src="/js/bootstrap.js"></script>
        <script src="/js/smooth-scroll.js"></script>
        <script type="text/javascript" src="/showdown/dist/showdown.min.js"></script>
        <!--<script src="/content/ZeroDream/js/instantclick.min.js" data-no-instant></script>-->
        <script>
            var _hmt = _hmt || [];
            (function() {
              var hm = document.createElement("script");
              hm.src = "https://hm.baidu.com/hm.js?95dc5602bc7aff740dbdb48d5342d3ba";
              var s = document.getElementsByTagName("script")[0]; 
              s.parentNode.insertBefore(hm, s);
            })();
            function to_top() {
                window.scroll({ top: 0, left: 0, behavior: 'smooth' });
            }
        </script>
</head>
<body>
    <div class="container" style="min-height: 966px;">
    <div class="row">
        <div class="topbar">
            <div class="logo">
                <p>
                    <span class="name">云中社</span>
                    <span class="description">故事分享论坛</span>
                </p>
            </div>
            <div class="menu">
                <div class="item">
                    <a href="/" data-no-instant="">论坛</a>
                </div>
                <div class="item">
                    <a href="#" target="_blank" data-no-instant="">官网</a>
                </div>
                <div class="item">
                                    <a href="#">大鹏</a>
                                </div>
                                <div class="item">
                                    <a href="/new-article" data-no-instant="">分享新故事</a>
                                </div>
            </div>
        </div>

        <div class="row selectnode">
            <div class="col-sm-9">
                <p>按分类浏览</p>
                <p>
                    <a href="/"><button class="btn btn-default">全部</button></a>&nbsp;&nbsp;<a href="#"><button class="btn btn-default">闲聊</button></a>&nbsp;&nbsp;<a href="#"><button class="btn btn-default">分享</button></a>&nbsp;&nbsp;<a href="#"><button class="btn btn-default">问答</button></a>&nbsp;&nbsp;<a href="#"><button class="btn btn-default">教程</button></a>&nbsp;&nbsp;<a href="#"><button class="btn btn-default">服务器</button></a>&nbsp;&nbsp;<a href="#"><button class="btn btn-default">编程</button></a>&nbsp;&nbsp;<a href="#"><button class="btn btn-default">推荐</button></a>&nbsp;&nbsp;<a href="#"><button class="btn btn-default">公告</button></a>&nbsp;&nbsp;<a href="#"><button class="btn btn-default">其他</button></a>&nbsp;&nbsp;
                </p>
            </div>
            <div class="col-sm-3 box">
                <form>
                    <div class="input-group input-group-sm" style="margin-top: 22px;">
                        <input name="search" class="form-control pull-right" placeholder="搜索标题、内容或作者" type="text">
                        <div class="input-group-btn">
                            <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-sm-12">
                <hr>
            </div>
        </div>
    <!-- 帖子开始 -->
    <div class="col-sm-9 postlist">
        <div class="content">
            <table class="threadtitle">
                <tbody>
                    <tr>
                        <td style="width: 90px;">
                            <img src="<?php echo $user['photo']; ?>" class="hdimg">
                        </td>
                        <td>
                            <h3><?php echo $article['title']; ?></h3>
                            <p><a href="/user/Akkariin" target="_blank"><?php echo $user['nickname']; ?></a> 发表于 <?php echo $article['time']; ?> | 查看：<?php echo $article['view']; ?></p>
                        </td>
                    </tr>
                </tbody>
            </table>
            <hr>
            <div class="thread">
                <div id="content"><?php echo $article['content']; ?></div>
                <p><small><?php echo $user['nickname']; ?> 在 2018-10-25 02:01:33 发表了帖子</small></p>
            </div>
                
            <hr>
            <div class="signdisplay thread">
                <p>云中人论坛开发者<br><a target="_blank" href="#"></a><br></p>
            </div>
            <hr>
            <p><b>发表你的评论</b></p>
            <p>回帖时请注意遵守论坛发言规定，请勿恶意灌水。</p>
            <p>
                <textarea class="form-control reply" id="chat" oninput="checkReplyLength()"></textarea>
            </p>
            <p class="text-right">
                <span class="reply-txt" style="float: left"><input type="checkbox" id="desc" onclick="getChatList(0, tid)" checked="">&nbsp;&nbsp;回帖倒序排列</span>
                <span class="reply-txt">您还可以输入 <span id="replylength">2000</span> 字</span>
                <button onclick="submitChat()" class="btn btn-danger">发表评论</button>
            </p>
            <!-- 评论内容 -->
            <div class="chat-list" id="chatlist" style="display: block;">
                <table id="chatajax">
                    <tbody>
                            <?php if(is_array($reply) || $reply instanceof \think\Collection || $reply instanceof \think\Paginator): $i = 0; $__LIST__ = $reply;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                        <tr>
                            <td class="headimg">
                                <a href="https://bbs.zerodream.net/user/xiaoqiu" target="_blank"><img style="width:65px;" src="<?php echo $v['photo']; ?>"></a>
                            </td>
                            <td class="chatbox">
                                <p>
                                    <small style="color: #aaa;">
                                        <usergroup>论坛创始者</usergroup> <a href="javascript:void(0);" onclick="ate(this)"><?php echo $v['author']; ?></a> 发表于 <?php echo $v['time']; ?>
                                    </small>
                                </p>
                                <div class="chat-content"><?php echo $v['content']; ?></div>
                            </td>
                        </tr>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                        
                    </tbody>
                </table>
            </div>
                <input type="hidden" id="tid" value="26">
                <script>
                    // InstantClick.init();
                    var content = document.getElementById('content').innerHTML;
                    var converter = new showdown.Converter();
                    var html = converter.makeHtml(content);
                    document.getElementById("content").innerHTML = html;
                    var chat_content = $('.chat_content').innerHTML;
                    console.log(chat_content);
                    // @功能
                    function ate(obj){
                        var txt = '@'+obj.innerHTML;
                        var textarea = $('#chat').val();
                        $('#chat').val(textarea+txt);
                    }
                    // 发表评论
                    function submitChat(){
                        var data = $('#chat').val();
                        alert(data);
                        $.ajax({
                        //几个参数需要注意一下
                            type: "POST",//方法类型
                            dataType: "json",//预期服务器返回的数据类型
                            url: "/ajax_reply" ,//url
                            data: {content:data,author:'云中人',reply:<?php echo $article['id']; ?>},
                            success: function (data) {
                                console.log(data);//打印服务端返回的数据(调试用)
                                var converter = new showdown.Converter();
                                data.content = converter.makeHtml(data.content);
                                if(data.status == '1'){
                                    var newhtml = '<tr><td class="headimg pcreplyhead"><a href="/user/大鹏" target="_blank"><img src="'+data.photo+'" style="display: inline; opacity: 1; filter: blur(0px);"></a></td><td class="chatbox"><p><small style="color: #aaa;"><usergroup>论坛创始人</usergroup> <a onclick="at(&quot;大鹏&quot;)">'+data.nickname+'</a> 发表于 刚刚 <a href="/editreply/'+data.replyid+'">编辑评论</a> | <a href="/delreply/'+data.replyid+'">删除评论</a></small></p><div class="chat-content"><p>'+data.content+'</p></div></td></tr>';
                                    $("#chatajax tbody").prepend(newhtml);
                                }
                            },
                            error : function() {
                                alert("异常！");
                            }
                        });
                    }

                    function checkReplyLength(){
                        var con = $("#chat").val();
                        var replylength =  2000 - con.length;
                        $("#replylength").text(replylength);
                    }
                </script>
        </div>
    </div>
    <!-- 帖子结束 -->
     <!-- 用户信息开始 -->
    <!-- <div class="col-sm-3 box">
        <br>
            <p>欢迎来到 纯仿制社区 论坛！</p>
            <p>您还没有登录噢 :P</p>
            <p>登陆以后就可以发帖和回复啦~</p>
            <p><a href="/openapi/?action=location"><button class="btn btn-danger">立即登录账号</button></a></p>
    </div> -->
    <div class="col-sm-3 box">
        <center><img src="/image/tx.jpg" class="headimg my">
                    <p class="text-center login-name"><a href="https://bbs.zerodream.net/user">大鹏</a></p></center>
                    <hr>
                    <p>主题数：<code>1</code></p>
                    <p>回复数：<code>2</code></p>
                    <p>积分数：<code>9</code></p>
                    <p>用户组：萌新</p>
                    <hr>
                    <div id="signature" class="thread" title="双击编辑签名" ondblclick="editsignature()" style="cursor: pointer;">暂时没有签名~</div>
                    <textarea class="form-control signature" id="signature-box" style="display: none;" onblur="submitSign()">暂时没有签名~</textarea>
    </div>
    <script src="/js/signature.js" data-no-instant=""></script>
    <script type="text/javascript" data-no-instant="">
        // 兼容 Firefox
        if (navigator.userAgent.indexOf('Firefox') >= 0) {
            var height = document.body.clientHeight + "px";
            $(".container").css({"min-height":height});
        }
        // InstantClick.init();
    </script>
</div>
<div class="row">
    <div class="col-sm-12 footer">
        <table class="ft-copyright">
            <tbody><tr>
                <td style="width: 180px;">
                    <p>
                        <img src="/image/logo.png" style="width: 122px;">
                    </p>
                </td>
                <td>
                    <p>友情链接</p>
                    <p><a href="https://bbs.zerodream.net/" target="_blank" data-no-instant="">ZeroDream BBS</a></p>
                    <p><a href="https://www.natfrp.org/" target="_blank" data-no-instant="">Sakura Frp</a></p>
                    <p><a href="https://www.phpmc.cn/" target="_blank" data-no-instant="">PHPMC 7</a></p>
                </td>
                <td class="text-right">
                    <p>© 2018 社区论坛</p>
                    <p>本论坛前端仿照ZeroDream BBS</p>
                    <p>框架 ThinkPHP5.0</p>
                </td>
            </tr>
        </tbody></table>
    </div>
</div>
</div>
<div class="to_top" onclick="to_top()"></div>