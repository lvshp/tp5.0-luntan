<?php

use think\Route;

Route::get('/','admin/index/index');
Route::get('/article/:id','admin/index/article');
Route::get('/new-article','admin/index/add');
Route::post('/doadd','admin/index/doadd');
Route::post('/ajax_reply','admin/index/ajax_reply');