<?php
namespace app\admin\controller;
use think\Controller;
use think\Db;
use think\Request;
use think\Parser;
class Index extends Controller
{

    public function index()
    {
        $list = DB::name('article')->paginate(10);
        $page = $list->render();
        $list = iterator_to_array($list);
        $i = 0;
        foreach($list as $k=>$v){
            $user = DB::name('user')->where(['id'=>$v['author']])->find();
            $list[$k]['nickname'] = $user['nickname'];
            $list[$k]['content'] = mb_substr($v['content'],0,15,'utf-8');
        }
        // echo '<pre>';
        // // var_dump($list->{0});
        // dump($list);
        // die;
        return view('index',['list'=>$list,'page'=>$page]);
    }

    /*
     *文章列表 
     * @param  int $id 文章id
     */
    public function article($id)
    {

        $article = DB::name('article')->where(['id'=>$id])->find();
        $article['time'] = date("Y-m-d H:i:s",$article['time']);
        $user = DB::name('user')->where(['id'=>$article['author']])->find();
        //评论内容
        $parser = new Parser;
        $reply = DB::name('reply')->where(['reply'=>$article['id']])->order('time')->select();
        foreach($reply as $k=>$v){
            $reply_user = DB::name('user')->where(['nickname'=>$v['author']])->find();
            $reply[$k]['content'] = $parser->makeHtml($v['content']);
            unset($reply_user['id']);
            $reply[$k] += $reply_user;
        }
        return view('article',['article'=>$article,'user'=>$user,'reply'=>$reply]);
    }

    //添加新文章
    public function add()
    {
        return view('add');
    }

    public function doadd()
    {
        $post =  input();
        $post['time'] = time();
        // $post['author'] = session('user.id');
        $post['author'] = "1";
        $res = DB::name('article')->insert($post);
        if($res){
            $this->redirect('/');
        }
    }
    // 发表评论
    public function ajax_reply()
    {
        $post = input();
        if ($post) {
            $post['time'] = time();
            $res = DB::name('reply')->insert($post);
            if($res){
                $data = DB::name('user')->where(['id'=>$post['reply']])->find();
                $data['replyid'] = DB::name('reply')->getLastInsID();
                $data['status'] = '1';
            }else{
                $data['status'] = '2';
            }
        }else{
            $data['status'] = '1';
        }
        echo json_encode($data);
    }
}
